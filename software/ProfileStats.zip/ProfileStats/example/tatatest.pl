#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Example!
#
# Usage:
# $PRG  [options]  Simple-matrix-file
#   -h       Help on usage
#   -D       Debug Mode
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; exit; }

my $debug=0;
sub debug
  { if($debug) {print STDERR @_,"\n"; } }

#################################################################


# PARSE OPTIONS
my %options;
getopts("Dh", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
$debug=$options{D};
if ($options{h}) { usage; exit(1); }

my $GC=50;
my $eps=0.01;
my $pval=0.001;

my ($file,$pfile);

$file=$ARGV[0];
usage() unless $file;
$pfile=$file;
if (!($pfile =~ s/\.\S+?$/.profile/)) { $pfile .= ".profile"; }


############################################################

sub cmpstatistics  # (\@common_probabilities, $alphaproduct)
  {
    my $cpref=shift;
    my @probs = @$cpref;
    my $alphaprod=shift;

    my @ss = sort {$a<=>$b} @probs;
    my $mm = $ss[-1];
    my $rr = $ss[-2]/$mm;

    my $sum=0;
    for(my $i=0; $i<=$#ss; $i++) { $sum+=$ss[$i]; }

    my $mpos=-1;
    for(my $i=0; $i<=$#probs; $i++)
      { if ($probs[$i]==$mm) {$mpos=$i;} }

    my $llr=log($mm/$alphaprod);

    my $result = "Maximum $mm at shift $mpos.  Log-Ratio=$llr.  Sum=$sum.  SecondBest/Maximum=$rr.\n";
    return($result);
  }




############################################################

# Load profiles P1,P2,P3
open(FIN,"<TATA.profile");
my ($h1,@P1)=read_profile(*FIN);
my ($h2,@P2)=read_profile(*FIN);
my ($h3,@P3)=read_profile(*FIN);
close(FIN);


# Get background pi: uniform
my @pi=getdist("GC=$GC",\@P1);

# Compute Score matrices S1,S2,S3
my @S1=profile2score(\@P1,\@pi,1,$eps);
my @S2=profile2score(\@P2,\@pi,1,$eps);
my @S3=profile2score(\@P3,\@pi,1,$eps);


# Get thresholds T1,T2,T3 (p-val = 0.05)
my (@PI1,@PI2,@PI3);
my $i;
for($i=0; $i<scalar(@S1); $i++) { $PI1[$i]=[@pi]; }
for($i=0; $i<scalar(@S2); $i++) { $PI2[$i]=[@pi]; }
for($i=0; $i<scalar(@S3); $i++) { $PI3[$i]=[@pi]; }


my ($mins,$maxs,$d,$c,@alpha,$ind);
my ($a1,$a2,$a3);
my ($t1,$t2,$t3);

($mins,$maxs,$d)=scoredist(\@S1,\@PI1, $eps);
$c = cumsums($d);
@alpha = map { $_->[2] } @$c;
# print "alpha1:  ",join(" ",@alpha),"\n";
for ($i=$#alpha; $i>=0 && $alpha[$i]<$pval;  $i--) {};
$ind = ($i==$#alpha)? $i : $i+1;
$a1=$alpha[$ind];
$t1 = roundeps($mins + $ind*$eps,  $eps);
print "1: $mins  $maxs $t1\n";

($mins,$maxs,$d)=scoredist(\@S2,\@PI2, $eps);
$c = cumsums($d);
@alpha = map { $_->[2] } @$c;
for ($i=$#alpha; $i>=0 && $alpha[$i]<$pval;  $i--) {};
$ind = ($i==$#alpha)? $i : $i+1;
$a2=$alpha[$ind];
$t2 = roundeps($mins + $ind*$eps,  $eps);
print "2: $mins  $maxs $t2\n";

($mins,$maxs,$d)=scoredist(\@S3,\@PI3, $eps);
$c = cumsums($d);
@alpha = map { $_->[2] } @$c;
for ($i=$#alpha; $i>=0 && $alpha[$i]<$pval;  $i--) {};
$ind = ($i==$#alpha)? $i : $i+1;
$a3=$alpha[$ind];
$t3 = roundeps($mins + $ind*$eps,  $eps);
print "3: $mins  $maxs $t3\n";


# Similarity

my @cmp13 = profile_similarity(\@S1,\@S3, $t1,$t3, \@pi);
print "1 vs 3:  ",join("   ",@cmp13),"\n\n";
my $stats = cmpstatistics(\@cmp13, $a1*$a3);
print $stats;


#my @cmp21 = profile_similarity(\@S2,\@S1, $t2,$t1, \@pi);
#print "2 vs 1:  ",join("   ",@cmp21),"\n\n";

