#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Sort profiles according to quality: For high-quality profiles
# (Q_balance >= 0.95), rank according to balance. For low-quality
# profiles, we sort according to Q_sens (at alpha_n=0.05).
#
# $PRG  [options]  Quality-file
#  -h  Help
#  -q  quiet
#  -t  TeX formatted output
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

##################################################################

my %val=();

sub byquality
  {
    my ($qa,$qb);
    $qa=($val{$a}->[6] >= 0.95)?($val{$a}->[6]):($val{$a}->[2]);
    $qb=($val{$b}->[6] >= 0.95)?($val{$b}->[6]):($val{$b}->[2]);
    return -($qa <=> $qb);
  }


################
# MAIN
################

my $quiet=0;
my $sep="";
my $endl="";
my $comm='#';

# PARSE OPTIONS
my %options;
getopts("DhqQt", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
if ($options{q} || $options{Q}) { $quiet=1; }
if ($options{t}) { $sep =  "&"; $endl = "\\\\"; $comm='%'; }


my ($desc, $ID);
while(<>)
  {
    next if (! m/^\#/);
    $desc=$_;
    die if (! m/^\#\s*(.*?)\|/);
    $ID = $1;
    $_ = <>;
    while (m/^\#/) { $_ = <>; }
    #print "{$ID} = (",join(" ",split),")\n";
    $val{$ID}=[split];
  }


my @sorted = sort byquality keys %val;
my ($i, $first, $q, $printid);

$first=1;
print "$comm \n$comm High Quality Profiles (Q_balance >= 0.95)\n",
  "$comm Sorted according to Q_balance in decreasing order\n$comm \n"
  unless $quiet;
for ($i=0; $i<scalar(@sorted); $i++)
  {
    $ID=$sorted[$i];
    $q=$val{$ID}->[6];
    if ($q<0.95)
      {
        if ($first)
          {
            $first=0;
            print "$comm \n$comm Low Quality Profiles (Q_balance < 0.95)\n",
              "$comm Sorted according to Q_sens (at alpha=0.05)\n$comm \n"
                unless $quiet;
          }
        $q=$val{$ID}->[2];
      }
    $printid=$ID;
    if ($options{t}) { $printid =~ s/\$/\\\$/g; $printid =~ s/_/\\_/g; }
    printf "%-25s   $sep  ",$printid;
    printf "%.4f  $endl\n",$q;
  }

#################################################################

