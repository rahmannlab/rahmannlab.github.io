#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;

my ($TARFILES, $XFILES);
my $DEST;


# PARSE OPTIONS
my %options;
getopts("tw", \%options);
if (!$options{t} && !$options{w})
  { die "Publish.pl: Specify option '-t' (Tools) or '-w' (Web).\n"; }

$TARFILES = "README  LICENSE  Count2Profile.pl  CountReg.pl  Profile2Score.pl  ProfileErrors.pl  ProfilePlot.pl  ProfileQuality.pl  ProfileScoreDist.pl  ProfileSort.pl  ProfileStats.pm  TFBS-Count.pl  TFBS-HQID.pl  TFBS-ExtractMatrix.pl  TFBS-Process.pl  TFBS-Search.pl";

$XFILES = "example/example.*  example/XMPL.*";

print STDERR "Tarring files...\n";
if (system ("gtar czf ProfileStats.tgz $TARFILES $XFILES"))
  {
    print STDERR "Trying normal tar.\n";
    if (system ("tar czf ProfileStats.tgz $TARFILES $XFILES"))
      {
	die "Publish.pl: Both 'gtar' and 'tar' failed";
      }
  }
print STDERR "Tarring successfully completed. Copying files...\n";


if ($options{w})
  {
    $DEST = "/home/cmb/genereg/htdocs/ProfileStats";
    system ("cp *.tgz README LICENSE $DEST/") and die "cp failed";
    system ("chmod -R go-w $DEST; chmod ug+rwx $DEST; chmod a+x $DEST; chmod -R a+r $DEST") and die "chmod failed";
  }
elsif ($options{t})
  {
    $DEST = "/project/gene-regulation/bin";
    system ("cp *.tgz $TARFILES $DEST/") and die "cp failed";
    if (! (-e "$DEST/examples/" && -d "$DEST/examples/"))
      { mkdir("$DEST/examples/") or die "mkdir failed"; }
    system ("cp $XFILES $DEST/examples/") and die "cp failed";
    system ("chmod -R go-w $DEST; chmod ug+rwx $DEST; chmod a+x $DEST; chmod -R a+r $DEST") and die "chmod failed";
    system ("chmod ug+rwx $DEST/examples; chmod a+x $DEST/examples") and die "chmod failed";
  }

print STDERR "Done.\n";
