#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Reads simple format matrix file and regularizes each matrix according
# to the specified options by adding pseudo-counts.
# After that, each row sum is normalized to its ORIGINAL value.
#
# Usage:
# $PRG  [options]  SimpleMatrixFile(s)
#  -d Distribution     Specify regularizing distribution, i.e., one of
#       uni[form]        uniform distribution
#       sum|av[erage]    average distribution of tge profile
#                          (slightly adjusted when it contains a 0 entry)
#       GC=nn            iid distribution with nn% GC-content (e.g. 50)
#  -w Weight           Specify mass for distribution, i.e., one of
#       nn               constant mass nn>0
#       Hdiff=x          such that scaled rel. entropy drops by x>0 nats
#       Hfactor=y        such that scaled r.e. drops by factor 0<y<1
#
# Recommended and Default is  '-d av  -w Hdiff=1.5'.
#   See the paper for details about this choice.
# To add 0.025 pseudo-counts to each ACGT for a
#   total regularizing weight of 0.1, use '-d uni  -w 0.1'.
# In order not to regularize, use '-w 0'.
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

#################################################################

################
# MAIN
################

my $dist;
my $weight;


# PARSE OPTIONS
my %options;
getopts("Dd:w:h", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
$dist=$options{d} || 'GC=av';
$weight=$options{w};
if (!defined($weight)) {$weight='Hdiff=1.5'};

my ($head, $lines);
my (@rows, @backgr, @rerows);

# Processing
while(<>)
  {
    chomp;
    if (m/^>/)
      {
        m/(\d+)$/; $lines=$1;
        $head=$_; @rows=(); @rerows=();
        while(<>)
          {
            chomp;
            last if (m/^</);
            push(@rows,[split(" ",$_)]);
          }
        die "$PRG: Wrong number of rows in [$head]"
          unless ($lines==scalar(@rows));

        # Regularize matrix:
        @backgr=getdist($dist,\@rows)
          or die "$PRG: Illegal '-d' option: [$dist]";
        @rerows=regularize(\@rows,\@backgr,$weight)
          or die "$PRG: Regularization failed for [$head]";

        # Write regularized matrix:
        print $head,"\n";
        print matrix2string(\@rerows),"\n<\n";
      }
  }

#################################################################
