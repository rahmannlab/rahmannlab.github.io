#!/bin/perl -w
# (c) Sven Rahmann, October 2003
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
#
# Matches a set of profiles against a set of FASTA sequences:
# - Estimates a background model for each sequence
# - Constructs a score matrix for each (profile,sequence) pair
# - Obtains background and signal score distribution for each
#   (profile,sequence) pair
# - Estimates mixture parameter of background and signal models
# - Estimates expected number of occurrences of TFBS-Signal
#
# Usage:
# $PRG  [options]  ProfileMatrixFile  FASTAFile(s)
#  -e  granularity  Rounding granularity (DEFAULT=0.05)
#  -r               Also search reverse complement of sequences
#  -u               Use unsymmetric (non GC-symmetric) background model
#                   Note: -u is ignored when -r is given
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

my $debug=0;
sub debug
  { if($debug) {print STDERR @_,"\n"; } }

##################################################################

sub getbackground  # (\@seq, $unsymm?)
  # From the sequence given by \@seq (numeric IUPAC codes),
  # estimate the background frequency distribution of letters
  # Symmetrize wrt A/T, G/C.
  {
    my ($seq,$unsymm) = @_;
    if (!defined($unsymm)) {$unsymm=0;}
    my ($s,$inc,$x);
    my @count=(0,0,0,0);

    foreach $s (@$seq) {
      $inc = 1.0 / scalar(@{$IUPACset[$s]});
      foreach $x (@{$IUPACset[$s]}) { $count[$x]+=$inc; }
    }
    debug("#    Letter counts: ",vector2string(\@count),"\n");
    if (!$unsymm) {
      my ($AT,$GC);
      $AT=($count[0]+$count[3])/2.0;
      $GC=($count[1]+$count[2])/2.0;
      @count[0..3] = ($AT,$GC,$GC,$AT);
    }

    die "getbackground: count has wrong length" unless (scalar(@count)==4);
    $inc=0; foreach $x (@count) { $inc+=$x; }
    for ($x=0; $x<4; $x++)  { $count[$x]/=$inc; }
    return @count;
  }


sub repvec  # (\@dist, $L)
  # Repeat distribution @dist exactly $L times
  {
    my ($d,$L) = @_;
    my @M;
    for (my $i=$L-1; $i>=0; $i--) { $M[$i] = [@$d]; }
    return @M;
  }

##################################################################


sub process   # (\@seq, \@profile, \@background, $eps)
  # Process sequence against profile
  # \@seq:         Numerical IUPAC codes
  # \@profile:     Profile matrix
  # \@background:  Background Matrix
  # $eps:          Rounding granularity
  # Returns expected number of occurences of the profile
  {
    my ($sref, $pref, $bref, $eps) = @_;
    my $L = scalar(@$pref);  # Profile length
    my (@srows,@brows);

    my ($mins,$maxs,$d0,$d1);
    my ($tau, $tauE,$tauML,$tauFL);

    # Obtain Score matrix and distributions
    @brows = repvec($bref, $L);
    @srows = profile2score($pref, $bref, 1, $eps);
    #print "***\n",matrix2string(\@brows),"\n***\n";

    ($mins,$maxs,$d1) = scoredist(\@srows, $pref,   $eps);
    ($mins,$maxs,$d0) = scoredist(\@srows, \@brows, $eps);

    # Score all windows in the sequence
    my ($Avg,$numscores,$numscoresH,$H)
      = profile_match_hists(\@srows, $sref, $mins,$maxs,$eps);

    $tauFL = mixcoefficient_FL($H,$numscoresH,$d0,$d1);
    #print "$tauE  $tauFL\n";
    return($numscores*$tauFL);
  }


##################################################################

################
# MAIN
################

my ($eps,$unsymm,$doRC, $pfile); # Options
my @phead = ();      # array of profile headers
my @profiles = ();   # array of profiles


# PARSE OPTIONS
my %options;
getopts("Dhe:ur", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
if ($options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
$debug=$options{D};

$eps=$options{e} || '0.05';
$unsymm = defined($options{u})? 1:0;
$doRC = defined($options{r})? 1:0;
if ($doRC) { $unsymm=0; }

$pfile = shift;
if (!defined($pfile))
  { usage; die "$PRG: You must specify a ProfileMatrixFile.\n"; }
my @args = @ARGV;


#
# Read all profiles
#
my $pnum = 0;
my ($head,@prows);
open(PFILE,"<$pfile") or die "Cannot open profile file '$pfile'";
do {
  ($head,@prows) = read_profile(*PFILE);
  if (defined($head)) {
    $head =~ m/^>(\S+?)[\|\s]/;
    $phead[$pnum]=defined($1)?$1:$head;
    $profiles[$pnum] = [ @prows ];
    print "# Profile $pnum: [$phead[$pnum]]\n";
    $pnum++;
  }
} while (defined($head));
close(PFILE) or die "Error closing profile file '$pfile";
print "# $pnum profiles read.\n";



#
# Process all (sequence, profile) pairs.
#
my ($i,$header,$line);
my ($Eocc,@Eoccs);
my (@seqnum,@seqnumR);
my (@backgr,@backgrR);

$|=1;  # Disable Output buffering

do { $header = <>; } while (defined($header) &&  $header!~ m/^>/);
while($header)
  {
    chomp($header); $line="";
    $header =~ s/^>//;
    print $header,"\t";
    @Eoccs = (0) x $pnum;
    @seqnum=();
    while(<>)
      {
        chomp;
        if (m/^>/) { $line=$_; last; }
        push(@seqnum,IUPAC2num($_));
      }
    @backgr = getbackground(\@seqnum, $unsymm);
    if ($doRC) {
      @seqnumR = map { $IUPACcomplement[$_] } (@seqnum);
      @backgrR = reverse(@backgr);
    }
    for ($i=0; $i<$pnum; $i++) {
      $Eocc  = process(\@seqnum,  $profiles[$i], \@backgr,  $eps);
      $Eocc += process(\@seqnumR, $profiles[$i], \@backgrR, $eps) if ($doRC);
      $Eoccs[$i]=$Eocc;
    }
    print join("\t",@Eoccs),"\n";
    $header=$line;
  }


__END__

#################################################################

# Estimate tau by (1) average score (2) ML (3) Frame-ML
#$tauE = mixcoefficient_E($Avg,$E0,$E1);
#printf "#   E0=%.4g,  Avg=%.4g,  E1=%.4g  --> tauE =%.4g\n",$E0,$Avg,$E1,$tauE;
#$tauML = mixcoefficient_ML(\@scores,\@d0,\@d1, $mins,$maxs,$eps);
#printf "#                                      --> tauML=%.4g\n",$tauML;
#$tauFL = mixcoefficient_FL(\@scores,\@d0,\@d1, scalar(@srows), $mins,$maxs,$eps);
#printf "# --> tauFL=%.4g\n",$tauFL;

