#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Process a given Transcription factor binding site profile
# in a standard way. You may take this script as a hint on how to set
# up your own processing pipeline. Before running this script, make
# sure that subdirectories png-33/, png-50/, and png-67/ exist to
# store images.
#
# Usage:
# $PRG  [options]  Simple-matrix-file
#   -h       Help on usage
#   -D       Debug Mode
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; exit; }

my $debug=0;
sub debug
  { if($debug) {print STDERR @_,"\n"; } }

#################################################################


my $ee=0.05;
my $nn=500;
my $tt=0.01;

# PARSE OPTIONS
my %options;
getopts("Dh", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
$debug=$options{D};
if ($options{h}) { usage; exit(1); }

my $GC;
my ($file,$pfile);

$file=$ARGV[0];
usage() unless $file;
$pfile=$file;
if (!($pfile =~ s/\.\S+?$/.profile/)) { $pfile .= ".profile"; }

system("CountReg.pl $file | Count2Profile.pl >$pfile") and die;

for $GC ((33,50,67))
  {
    my ($sfile,$d0file,$d1file,$distfile,$cdffile,$bdffile);
    my ($qfile,$qQfile,$rankfile, $path);
    ($sfile=$pfile)  =~ s/\.profile$/.score/;
    $sfile .= "-$GC";
    ($d0file=$pfile) =~ s/\.profile$/.dist0/;
    $d0file .= "-$GC";
    ($d1file=$pfile) =~ s/\.profile$/.dist1/;
    $d1file .= "-$GC";
    ($distfile=$pfile) =~ s/\.profile$/.dist/;
    $distfile .= "-$GC";
    ($cdffile=$pfile) =~ s/\.profile$/.err/;
    $cdffile .= "-$GC";
    ($bdffile=$pfile) =~ s/\.profile$/.fdr/;
    $bdffile .= "-$GC";
    ($qfile=$pfile) =~ s/\.profile$/.quality/;
    $qfile .= "-$GC";
    ($qQfile=$pfile) =~ s/\.profile$/.qualityQ/;
    $qQfile .= "-$GC";
    ($rankfile=$pfile) =~ s/\.profile$/.rank/;
    $rankfile .= "-$GC";
    $path = "png-$GC/";

    system("Profile2Score.pl -d GC=$GC -e $ee  $pfile >$sfile") and die;
    system("ProfileScoreDist.pl  $sfile >$d0file") and die;
    system("ProfileScoreDist.pl -p $pfile  $sfile >$d1file") and die;
    system("ProfileErrors.pl -p  $d0file $d1file > $distfile") and die;
    system("ProfileErrors.pl -n $nn $d0file $d1file > $cdffile") and die;
    #system("ProfileErrors.pl -t $tt $d0file $d1file > $bdffile") and die;
    system("ProfileQuality.pl $cdffile > $qfile") and die;
    system("ProfileQuality.pl -q $cdffile > $qQfile") and die;
    system("ProfilePlot.pl -t dist -p '$path' $distfile") and die;
    system("ProfilePlot.pl -t err  -p '$path' $cdffile") and die;
    system("ProfilePlot.pl -t roc  -p '$path' $cdffile") and die;
    system("ProfileSort.pl $qfile > $rankfile") and die;
  }

