#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Plot profile score distribution or error curves from
# distribution or errors file.
#
# $PRG  [options]  SAB-File
#  -h  Help
#  -t  type    Either 'dist','error', or 'roc' (for labelling only)
#  -f  format  Either 'png' (default) or 'eps' or 'pdf'
#  -p  path    Image path (defaults to './')
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

##################################################################

################
# MAIN
################


# PARSE OPTIONS
my %options;
getopts("Dht:f:p:", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
my $type = lc($options{t});
my $format = lc($options{f}) || 'png';
my $path = $options{p} || './';
if ($path !~ m/\/$/) {$path .= "/";}

my ($terminal,$ftype,$isize,$infopos);
my ($nn, $mm);

# Get type
my ($plottype,$fext);
if ($type =~ m/^d/)
  {
    $plottype = "Score Distribution";
    $fext = ".dist";
  }
elsif ($type =~ m/^e/)
  {
    $plottype = "Error Probabilities";
    $fext = ".err";
  }
elsif ($type =~ m/^r/)
  {
    $plottype = "ROC Curve";
    $fext = ".roc";
  }
else { usage(); die "$PRG: Illegal type option"; }


# Get format
if ($format =~ m/^(e(ps)?)|(pdf)/)
  { $terminal = "postscript eps color solid"; $ftype=".eps"; $isize=1; $infopos="graph 0.1,0.9"; }
elsif ($format =~ m/^p(ng)?/)
  { $terminal = "png"; $ftype=".png"; $isize=1.5; $infopos="graph 0.1,0.9"; }
else { usage; die "$PRG: Illegal format option"; }


# Processing
my $index=0;
my $Erw;
my ($head,$info,$SAB); $head="NONE";
my ($datafile, $title, $outfile);
$datafile=$ARGV[0];
while ($head)
  {
    ($head,$info,$SAB) = read_distribution(*ARGV);
    last if (!defined($head));
    #print "# [$head]\n";
    if ($head !~ m/(.*)\|(.*)\|(.*)$/)
      { die "Strange [$head] [$1][$2][$3]"; }
    $outfile = $path.$1.$fext.$ftype;
    #print "#   [$outfile]\n";
    $title = "$plottype for Profile".(($2)?" $2 ($1)":" $1");
    if ($3) { $title .= ", $3"; }
    $title =~ s/_/-/;

    # Set score according to info
    my ($minscore,$maxscore,$eps,$i);
    if ($info !~ m/min=(\S+)\s+eps=(\S+)\s+max=(\S+)/)
      { die "Unexpected info syntax [$info]"; }
    else
      { ($minscore,$eps,$maxscore) = ($1,$2,$3); }
    if ($info !~ m/E=(\S+)/)
      { die "Unexpected info syntax [$info]"; }
    else
      { $Erw=roundeps($1,$eps/100); }
    if ($info !~ m/n=(\d+)\s+m=(\d+)/)
      { $nn=$mm=0; }  else  { $nn=$1; $mm=$2; }

    # Open GNUPLOT pipe
    open(GNUP,"| gnuplot") || die "$PRG: Cannot open gnuplot";
    print GNUP <<END_OF_HEADER;
set term $terminal
set size $isize,$isize
set output "$outfile"
set title "$title"
END_OF_HEADER

    if ($type =~ m/^d/)
      {
        print GNUP <<END_OF_COMMANDS;
set xlabel "Score"
set ylabel "Probability"
set xrange [$minscore:$maxscore]
set label "Min Score = $minscore\\nMax Score = $maxscore\\nGranularity = $eps\\nQH = $Erw" at $infopos
plot '$datafile' index $index using 1:2 title 'Background' w lines, '' index $index using 1:3 title 'Signal' w lines
END_OF_COMMANDS
      }
    elsif ($type =~ m/^e/)
      {
        my $ylabel = "Error probabilities (n=$nn, m=$mm)";
        print GNUP <<END_OF_COMMANDS;
set xlabel "Score Threshold"
set ylabel "$ylabel"
set xrange [$minscore:$maxscore]
set label "Min Score = $minscore\\nMax Score = $maxscore\\nGranularity = $eps\\nQH = $Erw" at $infopos
plot '$datafile' index $index using 1:2 title 'Type-I error (p-value), n=$nn' w lines, '' index $index using 1:3 title 'Type-II error, m=$mm' w lines
END_OF_COMMANDS
      }
    elsif ($type =~ m/^r/)
      {
        # Get Quality Measures
        my ($tsens,$bsens, $tsel,$asel, $tbal,$abbal);
        my ($Qsens, $Qbal, $Qsel);
        my ($xlabel, $ylabel);
        my ($xxpos, $yypos);
        $xlabel = "Type-I error (p-value), n=$nn";
        $ylabel = "Type-II error, m=$mm";
        ($tsens,$bsens)=alpha2score($SAB,0.05); # beta for alpha=0.05
        ($tsel,$asel)=beta2score($SAB,0.05);    # alpha for beta=0.05
        ($tbal,$abbal)=alphabeta2score($SAB);
        $bsens=roundeps($bsens,0.0001); $Qsens=roundeps(1-$bsens,0.0001);
        $asel=roundeps($asel,0.0001);   $Qsel=roundeps(1-$asel,0.0001);
        $abbal=roundeps($abbal,0.0001); $Qbal=roundeps(1-$abbal,0.0001);
        $xxpos = ($asel<0.9)?$asel:0.9;
        $yypos = ($bsens<0.97)?$bsens:0.97;
        print GNUP <<END_OF_COMMANDS;
set xlabel "$xlabel"
set ylabel "$ylabel"
rmax = ($abbal*5<1)?$abbal*5:1
rmax = (rmax<0.001)?0.001:rmax
set xrange [0:rmax]
set yrange [0:rmax]
set label " $abbal (t=$tbal)" at $abbal,$abbal
set label "$asel (t=$tsel)" at $xxpos,0.055
set label " $bsens (t=$tsens)" at 0.05,$yypos
set label "Qsens(0.05; $nn,$mm) = $Qsens\\nQbal(1; $nn,$mm) = $Qbal\\nQsel(0.05; $nn,$mm) = $Qsel" at $infopos
plot '$datafile' index $index using 2:3 notitle w lines, '-'  notitle w lines lt 0, '-' notitle w lines lt 0, '-' notitle w lines lt 0
0 0
0.0001 0.0001
0.05 0.05
1 1
e
0.05 0
0.05 $bsens
0    $bsens
e
0 0.05
$asel 0.05
$asel 0
e
END_OF_COMMANDS
      }
    close(GNUP) || die "$PRG: gnuplot failed";
    $index++;

    # For pdf output, convert eps to pdf
    if ($format =~ m/^pdf/)
      {
        my $pdffile = $outfile;
        $pdffile =~ s/\.eps/.pdf/;
        $pdffile =~ s/\$/\\\$/g;
        # print "# epstopdf --outfile='$pdffile'  '$outfile'\n";
        system("epstopdf --outfile='$pdffile'  '$outfile'")
          and die "epstopdf failed";
        unlink($outfile) or die "unlink failed";
      }
  }

#################################################################

