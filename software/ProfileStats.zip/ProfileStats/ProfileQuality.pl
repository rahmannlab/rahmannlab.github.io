#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Compute Quality Measures for Profiles from 'errors' file,
# containing (score, alpha, beta) triples (one per line)
#
# $PRG  [options]  SAB-File
#  -h  Help
#  -q  Quiet mode: Do not print header lines
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

##################################################################


my $quiet=0;

################
# MAIN
################


# PARSE OPTIONS
my %options;
getopts("DhqQ", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
if ($options{q} || $options{Q}) {$quiet=1;}


# Processing
my $Erw;
my ($tsens,$bsens, $tsel,$asel, $tbal,$abbal);
my ($head,$info,$SAB); $head="NONE";
while ($head)
  {
    ($head,$info,$SAB) = read_distribution(*ARGV);
    last if (!defined($head));

    # Set score according to info
    my ($minscore,$maxscore,$eps,$i);
    if ($info !~ m/min=(\S+)\s+eps=(\S+)\s+max=(\S+)/)
      { die "Unexpected info syntax [$info]"; }
    else
      { ($minscore,$eps,$maxscore) = ($1,$2,$3); }
    if ($info !~ m/E=(\S+)/)
      { die "Unexpected info syntax [$info]"; }
    else
      { $Erw=roundeps($1,$eps/100); }

    # Get Quality Measures
    ($tsens,$bsens)=alpha2score($SAB,0.05); # beta for alpha=0.05
    ($tsel,$asel)=beta2score($SAB,0.05);    # alpha for beta=0.05
    ($tbal,$abbal)=alphabeta2score($SAB);   # where is alpha==beta?

    if (!$quiet)
      {
        print "\n# $head\n";
        print "#  Q_H    t_sens  Q_sens    t_sel  Q_sel    t_bal  Q_bal\n";
      }

    print "$Erw\t";
    print "$tsens\t",1-$bsens,"\t";
    print "$tsel\t",1-$asel,"\t";
    print "$tbal\t",1-$abbal,"\n";
  }

#################################################################

