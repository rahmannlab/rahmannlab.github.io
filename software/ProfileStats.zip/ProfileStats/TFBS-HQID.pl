#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Extracts TFBS IDs of high quality TFBSs from given rank files
#
# Usage:
# $PRG  [options]  Rank-file(s)
#   -h                  Help on usage (applies to all scripts)
#   -D                  Debug Mode (applies to all scripts)
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; exit; }

my $debug=0;
sub debug
  { if($debug) {print STDERR @_,"\n"; } }

#################################################################

my $Qlimit;
my $Climit;
my $Tlimit;

#################################################################

# PARSE OPTIONS
my %options;
getopts("Dh", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
$debug=$options{D};
if ($options{h}) { usage; exit(1); }

$Qlimit = 0.9;
$Climit = scalar(@ARGV);
$Tlimit = 'V';

my %seen = ();
my ($id,$q);
while(<>)
  {
    next if (m/^\#/);
    ($id,$q)=split;
    if ($q>=$Qlimit) {
      if ((!$Tlimit) || (substr($id,0,1) eq $Tlimit)) { $seen{$id}++; }
    }
  }

my $idstring="' ";
my $count=0;
foreach $id (keys %seen)
  {
    if ($seen{$id}>=$Climit) { $idstring .= ",$id"; $count++; }
  }
$idstring .= "'";
if (!$idstring) { $idstring = "'  '"; }
print $idstring;
#print "\n$count\n";
