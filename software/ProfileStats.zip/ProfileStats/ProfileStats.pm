package ProfileStats;
use strict;
use strict 'refs';
use Carp;  # 'croak' instead of 'die'; 'carp' instead of 'warn'
######################################################################

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
$VERSION     = 0.90;
@ISA         = qw(Exporter);

@EXPORT      = qw(&roundeps &entropy &vector2string &matrix2string &normalizerows &getdist &IUPAC2num &profile2score &profile2scoreIUPAC &regularize &scoreexpectation &scoredist &read_profile &cumsums &read_distribution &alpha2score &beta2score &alphabeta2score &profile_match &scorehist &profile_match_hists &mixcoefficient_E &mixcoefficient_ML &mixcoefficient_FL &mixcoefficient_plot &profile_similarity @IUPACalphabet %IUPACnumber @IUPACcomplement @IUPACset);

%EXPORT_TAGS= ();     # eg: TAG => [ qw!name1 name2! ],
@EXPORT_OK   = ();
######################################################################

use vars qw($Version $Author $Date);
$Version = "v$VERSION";
$Author  = "Sven Rahmann";
$Date    = "21-Sep-2003";

######################################################################

use vars qw($DEBUG);
$DEBUG=0;
sub debug
  { if($DEBUG) {print STDERR @_,"\n"; } }

######################################################################

sub is_valid_pattern  # (perl-pattern)
  {
    my ($pat) = @_;
    return eval { "" =~ /$pat/; 1 } || 0;
  }

######################################################################

sub roundeps # ($value, $eps)  or  (\@matrix, $eps)
  # Rounds a value or vector or matrix to granularity $eps
  # Vectors and matrices must be passed via reference!
  # Does not round in place, but creates a new rounded matrix
  # Matrix is returned as an array of references to arrays
  {
    my ($v,$e)=@_;

    # Single value
    if (!ref($v)) {
      return(undef) unless (scalar(@_)==2);
      return ($e*sprintf("%.0f",($v/$e)));
    }

    # Matrix or vector
    return ()  unless (scalar(@_)==2);
    my $rows=scalar(@$v);
    my @m; $#m=$rows-1;
    for (my $i=0; $i<$rows; $i++)
      {
        my $w=$v->[$i];
        if (!ref($w)) { $m[$i]=($e*sprintf("%.0f",($w/$e))); }
        else { $m[$i] = [ map { $e*sprintf("%.0f",($_/$e)) } (@$w) ]; }
      }
    return @m;
  }

######################################################################

sub entropy # (\@dist1, \@dist2)
  # Compute relative entropy in nats between two distributions.
  # Returns undef and emits a warning in case of errors.
  # Distributions must be passed by reference, have the same length,
  # and sum to 1.
  {
    my @tau=@{$_[0]};
    my @pi=@{$_[1]};

    if (scalar(@pi)!=scalar(@tau)) {
      carp("entropy: distributions must have same length");
      return undef;
    }
    my $k=scalar(@tau);
    my $tsum=0;
    my $psum=0;
    my $i;
    my $H=0;

    for ($i=0; $i<$k; $i++)
      {
        $tsum+=$tau[$i]; $psum+=$pi[$i];
        if ($tau[$i]!=0)
          { $H+= $tau[$i] * log($tau[$i]/$pi[$i]); }
      }
    $tsum-=1;  $psum-=1;
    if  (!((abs($tsum)<1E-13) && (abs($psum)<1E-13))) {
      carp("entropy: distributions don't add to 1; Errors are ($tsum; $psum)");
      return undef;
    }
    return $H;
  }


######################################################################

sub vector2string  # (\@vector, $column_delimiter)
  # Generates a printable string out of a vector
  # Column delimiter defaults to space
  {
    my ($v,$c) = @_;
    if (!ref($v)) { carp("vector2string: No reference given"); return ""; }
    if (!defined($c)) { $c = " ";  }
    return(join($c, (@$v)));
  }


sub matrix2string  # (\@matrix, $column_delimiter, $row_delimiter)
  # Generates a printable string out of a matrix
  # Column delimiter defaults to space
  # Row delimiter defaults to "\n"
  {
    my ($m,$c,$r) = @_;
    if (!ref($m)) { carp("matrix2string: No reference given"); return ""; }
    if (!defined($c)) { $c = " ";  }
    if (!defined($r)) { $r = "\n"; }
    return(join($r, map { join($c,@$_) } (@$m)));
  }

######################################################################

sub normalizerows # (\@matrix, $rowsum)
  # Normalize each row of input matrix to sum to $rowsum
  # If $rowsum is not given, it is assumed to be 1.
  # Return matrix of normalized rows (array of refs to arrays)
  # Return () in case of errors
  #   (wrong number of columns; negative elements)
  {
    my ($rs,$mysum)=@_;
    if (!defined($mysum)) { $mysum=1; }
    my @rr=();
    my $r;
    my $cols=0;

    foreach $r (@$rs)
      {
        my ($i,$ssum);
        my @v = @$r;
        $cols ||= scalar(@v);
        return () unless (scalar(@v)==$cols);
        for($i=0; $i<$cols; $i++)
          {
            return () unless ($v[$i]>=0);
            $ssum+=$v[$i];
          }
        for($i=0; $i<$cols; $i++) { $v[$i]*=$mysum/$ssum; }
        push(@rr,[ @v ]);
      }
    return @rr;
  }

######################################################################

sub getdist # ($diststring, \@matrix)
  # Construct a distribution from a string ($diststring)
  # and possibly from a matrix.
  # Returns and array with the distribution, or () on error
  # diststring can be one of the following:
  #  'uni'    uniform distribution
  #  'av'     average distribution of matrix
  #  'GC=##'  only for DNA, specify GC-content as ## per cent
  #  'GC=av'  only for DNA, speficy GC-content as average of matrix
  {
    return () unless (scalar(@_)==2);
    my ($d,$pr) = @_;
    my @dist;

    my $cols;
    if (!ref($pr)) { $cols = $pr; }
    else { $cols=$#{@$pr[0]}+1; }

    if ($d =~ m/^uni/i)
      {
        my $i;
        for($i=$cols; $i>0; $i--) { $dist[$i-1]=1/$cols; }
      }
    elsif ($d =~ m/^(?:GC=)?(?:av|sum)/i)
      {
        my (@sum, $ssum, $r, $i, $zeros);
        $sum[$cols-1]=0; $ssum=0;
        foreach $r (@$pr)
          {
            my @v=@$r;
            unless (scalar(@v)==$cols) {
              carp("getdist: row [$r] has wrong number of colums");
              return ();
            }
            for($i=0; $i<$cols; $i++) { $sum[$i]+=$v[$i]; $ssum+=$v[$i]; }
          }
        for($i=0; $i<$cols; $i++) { if ($sum[$i]==0) {$zeros++;} }
        if ($zeros)
          {
            debug("getdist: Average distribution contains zeros");
            for($i=0; $i<$cols; $i++) { $sum[$i]+=1/$cols; }
            $ssum+=1;
          }
        for($i=0; $i<$cols; $i++) { $dist[$i]=$sum[$i]/$ssum; }
        if ($d =~ m/^GC=/i)
          {
            if ($cols !=4) {
              carp("getdist: '-d GC' option requires 4-column matrix");
              return ();
            }
            my $at = ($dist[0]+$dist[3])/2.0;
            my $gc = ($dist[1]+$dist[2])/2.0;
            @dist = ($at,$gc,$gc,$at);
          }
      }
    elsif ($d =~ m/^GC=([\d\.]+)$/i)
      {
        my $GC=$1;
        if ($cols !=4) {
          carp("getdist: '-d GC' option requires 4-column matrix");
          return ();
        }
        if ($GC<=0 || $GC>=100) {
          carp("getdist: GC content must satisfy 0<GC<100");
          return ();
        }
        @dist = ( 0.5-$GC/200.0, $GC/200.0, $GC/200.0, 0.5-$GC/200.0);
      }
    else {
      carp("getdist: illegal distribution string '$d'");
      return ();
    }
    return @dist;
  }


######################################################################


use vars qw(@IUPACalphabet %IUPACnumber @IUPACcomplement @IUPACset);
@IUPACalphabet = qw(A C G T R Y M K S W B D H V N);
@IUPACset = ([0],[1],[2],[3],[0,2],[1,3],[0,1],[2,3],[1,2],[0,3],
             [1,2,3],[0,2,3],[0,1,3],[0,1,2],[0,1,2,3]);
%IUPACnumber = ();

{
  my $i;
  my @IUPACalphabetc = qw(T G C A Y R K M S W V H D B N);
  for($i=scalar(@IUPACalphabet)-1; $i>=0; $i--)
    { $IUPACnumber{$IUPACalphabet[$i]}=$i; }
  for($i=scalar(@IUPACalphabet)-1; $i>=0; $i--)
    { $IUPACcomplement[$i] = $IUPACnumber{$IUPACalphabetc[$i]}; }
}


sub IUPAC2num  # ($sequence)
  # Returns array of IUPAC numbers
  {
    return (map { $IUPACnumber{$_} } (split('',uc($_[0]))) );
  }



######################################################################


sub profile2score # (\@P, \@dist, $scale, $eps)
  # Convert each row in profile \@P into ln-odds score against \@dist
  # Scale scores by $scale and round to granularity $eps
  # Returns () in case of error
  # Returns array of references to arrays ("score matrix")
  # \@P:    reference to array of references to arrays ("profile matrix")
  # \@dist: reference to array ("background distribution")
  # $scale: scaling factor before rounding (e.g., 1.0)
  # $eps:   rounding granularity
  {
    return() unless (scalar(@_)>=2);
    my ($pr,$d,$s,$e) = @_;
    if (!defined($s)) { $s=1; }
    if (!defined($e)) { $e=0.01; }
    my $r;
    my @sr; $#sr=scalar(@$pr)-1;
    my $cols=0;
    my $ll=0;

    foreach $r (@$pr)
      {
        my (@v, $i);
        @v=@$r; $cols ||= scalar(@v);
        return() unless (scalar(@v)==$cols);
        for($i=0; $i<$cols; $i++)
          {
            my $score=$s*log($v[$i]/$$d[$i]);        # Scaled log-odds
            $v[$i]=($e*sprintf("%.0f",($score/$e))); # Round to eps
          }
        $sr[$ll++]=[@v];
      }
    return @sr;
  }



sub profile2scoreIUPAC # (\@prows, \@dist, $scale, $eps)
  # Convert each profile row in \@prows into ln-odds score against @dist
  # Produce EXTENDED score matrix by IUPAC code
  # Returns () in case of error
  # Same interface as 'profile2score', but gives extended matrix (DNA)
  {
    return() unless (scalar(@_)>=2);
    my ($pr,$d,$s,$e) = @_;
    if (!defined($s)) { $s=1; }
    if (!defined($e)) { $e=0.01; }
    my $r;
    my @sr; $#sr=scalar(@$pr)-1;
    my $ll=0;

    foreach $r (@$pr)
      {
        my (@v, $i);
        return() unless (scalar(@$r)==4);        # DNA only !
        $v[scalar(@IUPACset)-1]=0;
        for($i=0; $i<4; $i++)
          {
            my $score=$s*log($$r[$i]/$$d[$i]);        # Scaled log-odds
            $v[$i]=($e*sprintf("%.0f",($score/$e))); # Round to eps
          }
        for($i=4; $i<scalar(@IUPACset); $i++)
          {
            my @set = @{$IUPACset[$i]};
            my ($pp,$dd,$j);
            $pp=$dd=0;
            foreach $j (@set) { $pp+=$$r[$j]; $dd+=$$d[$j]; }
            my $score = $s*log($pp/$dd);
            $v[$i]=($e*sprintf("%.0f",($score/$e))); # Round to eps
          }
        $sr[$ll++]=[@v];
      }
    return @sr;
  }



######################################################################
######################################################################
######################################################################


sub regularize # (\@matrix, \@dist, $weight)
  # Regularize a count matrix
  # Each row is regularized with distribution dist,
  # according to a method specified by $weight:
  #  - ##:        In every row, add wgt*dist to the matrix
  #  - hdiff=#:   Regularize until drop in entropy
  #  - hfactor=#: Regularize until factor drop of entropy
  # Returns regularized matrix; no particular row sums
  {
    return () unless (scalar(@_)==3);
    my ($matrix,$d,$w) = @_;
    my $r;
    my @v;
    my @dist=@$d;
    my @rr=();
    my $cols=0;
    my $owgt;

    foreach $r (@$matrix)
      {
        my $i;
        @v=@$r;
        $cols ||= scalar(@v);
        unless (scalar(@v)==$cols) {
          carp("regularize: row has wrong number of colums");
          return ();
        }

        # Compute row sum $owgt
        $owgt=0; foreach (@v) { $owgt += $_; }

        # Constant numeric weight
        if ($w =~ m/^([\d+\.eE\+\-]+)$/)
          {
            my $wgt=$1;
            for($i=0; $i<$cols; $i++) { $v[$i]+=$wgt*$dist[$i]; }
          }

        # Rel. entropy difference / factor
        elsif ($w =~ m/^h(diff|factor)=(\S+)$/i)
          {
            my $ht=$1;   my $hh=$2;
            my (@vdist, @vv);
            for($i=0; $i<$cols; $i++) { $vdist[$i]=$v[$i]/$owgt; }
            my $wgtH=1; my $wgtL=0; my $wgt=0.5;
            my $ent;
            my $oent= 2*$owgt * entropy(\@vdist,\@dist);
            if (!defined($oent)) {return();}
            my $tent=($ht eq "diff")?($oent-$hh):($oent*$hh);
            if ($tent<=0) { $tent=$ent=0; $wgt=$wgtH; }
            while(abs($wgt-$wgtH)>1E-14)
              {
                for($i=0; $i<$cols; $i++)
                  { $vv[$i] = (1-$wgt)*$vdist[$i] + $wgt*$dist[$i]; }
                $ent= 2*$owgt * entropy(\@vv,\@dist)
                  or return ();
                last if (abs($ent-$tent)<1E-10);
                if ($ent>$tent) { $wgtL=$wgt; } else { $wgtH=$wgt; }
                $wgt=($wgtH+$wgtL)/2.0;
                #debug(" ## $wgt  $ent  $tent");
              }
            for($i=0; $i<$cols; $i++)
              { $v[$i] = (1-$wgt)*$vdist[$i] + $wgt*$dist[$i]; }
            debug("Type=$ht; Parameter=$hh; Used weight $wgt");
            debug("Entropy=$oent -> $ent (target=$tent)");
          }

        # Illegal weight option
        else {
          carp("regularize: illegal weight '$w' given");
          return ();
        }

        # Renormalize; Push line into @rr
        push(@rr,[@v]);
      }

    # DONE.
    return @rr;
  }

######################################################################
######################################################################
######################################################################


sub checksizes #  (\@Scorematrix, \@Profile)
  {
    my ($S,$P) = @_;
    my ($rows,$cols,$colp);

    $rows=scalar(@$S);
    unless ($rows==scalar(@$P)) {
      carp("checksizes: Score and Profile must have same size (rows)");
      return();
    }
    $cols=scalar(@{$$S[0]});  $colp=scalar(@{$$P[0]});
    unless ($cols>=$colp) {
      carp("checksizes: Score ($cols) and Profile ($colp) must have same \#cols");
      return();
    }
    return($rows,$colp);
  }

######################################################################

sub scoreexpectation  # (\@S, \@P, $eps)
  {
    # Compute expectation of @S under @P.
    # Requires that scores in @S are rounded to granularity eps.
    # Returns expectation

    my ($Sr,$Pr,$eps) = @_;
    my ($rows,$colp) = checksizes($Sr,$Pr);
    my ($sr,$sc,$i,$j);
    my $E=0;

    return undef unless $rows && $colp;
    $i=0;
    foreach $sr (@$Sr) {
      $j=0;
      foreach $sc (@$sr) { $E += $sc*$$Pr[$i][$j++]; }
      $i++;
    }
    return $E;
  }

######################################################################

sub scoredist # (\@S, \@P, $eps)
  {
    # Compute distribution of summed scores from @S when
    # position specific score distribution is @P.
    # Requires that scores in @S are rounded to granularity eps.
    #
    # Returns (minscore, maxscore, reference to distribution vector)
    #
    my ($Sr,$Pr,$eps) = @_;
    my ($rows,$colp) = checksizes($Sr,$Pr);
    my ($minscore,$maxscore,$len, $Rdist);
    my (@Si,@Pi, $s, $mini,$maxi, $nlen, $Rodist, @offset);
    my ($i, $j, $dz, $z);

    return () unless $rows && $colp;
    $minscore=0; $maxscore=0; $len=1; $Rdist=[1];
    for($i=0; $i<$rows; $i++)
      {
        # Convolute row $i into @dist via reference $Rdist
	@Si=@{$$Sr[$i]};  @Pi=@{$$Pr[$i]};
	$mini=$Si[0]; $maxi=$Si[0];
	foreach $s (@Si)
	  { if($s<$mini) {$mini=$s;}  if($s>$maxi) {$maxi=$s;} }
	$nlen=1+sprintf("%.0f",(($maxscore+$maxi)-($minscore+$mini))/$eps);
	$Rodist=$Rdist; $Rdist=[ (0) x $nlen ];
        @offset = map {sprintf("%.0f",($_-$mini)/$eps)} (@Si);

        $z=-1;
        foreach $dz (@$Rodist)
          {
            $z++;
            next unless $dz;
            for($j=0; $j<$colp; $j++)
              { $$Rdist[$z+$offset[$j]] += $dz*$Pi[$j]; }
          }
	$len=$nlen; $maxscore+=$maxi; $minscore+=$mini;
      }

    #my $dsum=0;
    #foreach (@$Rdist) { $dsum+=$_; }
    #debug("Distribution sum deviation from 1.0: ",$dsum-1.0);
    return ($minscore,$maxscore,$Rdist);
  }

######################################################################

sub cumsums # (\@pi)
  {
    # In:  Distribution @pi via reference
    # Out: Reference to
    #      3-column array with pi and cumulative sums ( . , < , >= )
    #      We use < instead of <= to have the complementary values for >=
    #      [ pi, pile, pige ]
    if (wantarray) { croak("cumsums: Called in array context"); }
    my ($pi) = @_;
    my $len=scalar(@$pi);
    my ($i,$c);
    my $out;

    $out = [(0) x $len];
    for ($c=0,$i=0; $i<$len; $i++)
      { $$out[$i] = [$$pi[$i], $c, 0]; $c+=$$pi[$i]; }
    for ($c=0,$i=$len-1; $i>=0; $i--)
      { $c+=$$pi[$i]; $$out[$i][2]=$c; }
    return $out;
  }

##################################################################


sub alpha2score # (\@SAB, $t_alpha)
  {
    # In:  3-cloumn matrix of (score, alpha, beta),
    #      alpha-threshold $t_alpha
    # Out: smallest score such that alpha <= t_alpha,
    #      Corresponding beta
    my ($SAB,$talpha) = @_;
    my ($i,@row);
    for ($i=scalar(@$SAB)-1; $i>=0; $i--)
      {
        @row = @{$$SAB[$i]};
        last if ( $row[1] > $talpha );
      }
        @row = @{$$SAB[$i+1]};
    return wantarray?($row[0],$row[2]):$row[0];
  }


sub beta2score # (\@SAB, $t_beta)
  {
    # In:  3-cloumn matrix of (score, alpha, beta),
    #      alpha-threshold $t_alpha
    # Out: largest score such that beta <= t_alpha,
    #      Corresponding alpha
    my ($SAB,$tbeta) = @_;
    my ($i,@row);
    for ($i=0; $i<scalar(@$SAB); $i++)
      {
        @row = @{$$SAB[$i]};
        last if ( $row[2] > $tbeta );
      }
    @row = @{$$SAB[$i-1]};
    return wantarray?($row[0],$row[1]):$row[0];
  }


sub alphabeta2score # (\@SAB)
  {
    # In:  3-cloumn matrix of (score, alpha, beta)
    # Out: Score such that alpa == beta
    #      Corresponding alpha (==beta)
    # (Equality is approximate since they won't be exactly equal)
    my ($SAB) = @_;
    my ($i,@row,@row1, $sc,$e);
    for ($i=0; $i<scalar(@$SAB); $i++)
      { # Starts with alpha>beta, ends with alpha<=beta
        @row = @{$$SAB[$i]};
        last if ( $row[1] <= $row[2] );
      }
    # Consider row i and i-1: min(max(i-1),max(i))
    @row1 = @{$$SAB[$i-1]};
    @row  = @{$$SAB[$i]};
    if ($row1[1]<$row[2]) { $sc=$row1[0]; $e=$row1[1]; }
    else { $sc=$row[0]; $e=$row[2]; }
    return wantarray?($sc,$e):$sc;
  }

##################################################################
##################################################################
##################################################################


sub profile_match # (\@PSSM, \@sequence)
  # Match PSSM of length L against each sequence window of length L
  # Sequence must be array of numbers from 0 .. asize-1
  # Record vector of scores, use 'undef' if character >= asize appears
  {
    my ($Sref, $seqref) = @_;
    my $L=scalar(@$Sref);     # L =  length of profile
    my $nn=scalar(@$seqref);  # length of sequence
    my $n=$nn-$L+1;           # n = number of L-windows in sequence

    my ($i,$j, $w);
    my ($m, $sum);
    my ($r, $rr);

    my $result = [(undef) x $n];
    $sum=0; $m=0;

  RESULT:
    for($i=0; $i<$n; $i++)
      {
        $r=0; $j=0;
        foreach $w (@$seqref[$i..$i+$L-1]) {
          next RESULT if (!defined($rr = $Sref->[$j++][$w]));
          $r += $rr;
        }
        $$result[$i]=$r;
        $sum+=$r; $m++;
      }

    my $Avg = ($m>0)? $sum/$m : 0;
    return ($Avg, $result);
  }

##################################################################

sub profile_match_hists # (\@PSSM, \@sequence, mins, maxs, eps)
  # Match PSSM of length L against each sequence window of length L
  # Sequence must be array of numbers from 0 .. asize-1
  # Record L histograms of scores; return by reference (see below)
  {
    my ($Sref, $seqref, $mins, $maxs, $eps) = @_;
    my $L=scalar(@$Sref);     # L =  length of profile
    my $nn=scalar(@$seqref);  # length of sequence
    my $n=$nn-$L+1;           # n = number of L-windows in sequence
    my $HSIZE = 1+sprintf("%.0f",($maxs-$mins)/$eps);
    #                         # Histogram size
    my ($f,$i,$j,$w);
    my ($r,$rr);
    my $sum = 0;
    my $numsc=0;
    my $numscs = [ (0) x $L ];
    my $hists;

    for ($f=$L-1; $f>=0; $f--)  { $hists->[$f] = [ (0) x $HSIZE ]; }

    $f=$L-1;
  RESULT:
    for($i=0; $i<$n; $i++)
      {
        $r=0; $j=0;  if (++$f == $L) {$f=0;}
        foreach $w (@$seqref[$i..$i+$L-1]) {
          next RESULT if (!defined($rr = $Sref->[$j++][$w]));
          $r += $rr;
        }
        $$hists[$f][sprintf("%.0f",($r-$mins)/$eps)]++;
        $$numscs[$f]++;
        $numsc++;
        $sum+=$r;
      }

    my $Avg = ($numsc>0)? $sum/$numsc : 0;
    return ($Avg, $numsc, $numscs, $hists);
  }

##################################################################

sub scorehist  # (\@scores, mins, maxs, eps)
  {
    # Returns number of scores != undef
    # Returns reference into histogram

    my ($sref,$mins,$maxs,$eps) = @_;
    my $n=scalar(@$sref);                          # Number of scores
    my $L = 1+sprintf("%.0f",($maxs-$mins)/$eps);  # Number of bins
    my $h = [ (0) x $L ];                          # Init with 0s
    my $s;
    my $numsc=0;

    foreach $s (@$sref) {
      next if !defined($s);
      $$h[sprintf("%.0f",($s-$mins)/$eps)]++;
      $numsc++;
    }

    unless (scalar(@$h)==$L) {
      carp "scorehist: histogram too long: ",scalar(@$h)," > $L";
      return ();
    }
    return ($numsc,$h);
  }


sub scorehists  # (\@scores, mins, maxs, eps, profilelength FF )
  # Returns ($numsc, $numscs, $hists)
  # $numsc         total number of score values != undef
  # $$numscs[$f]   total number of score values != undef in frame $f
  # $$hists[$f]    reference to score histogram for frame $f ($f=0..$FF-1)
  {
    my ($sref,$mins,$maxs,$eps, $FF) = @_;
    my $n=scalar(@$sref);
    my $L = 1+sprintf("%.0f",($maxs-$mins)/$eps);
    my ($f,$s);

    my $numsc=0;
    my $numscs = [ (0) x $FF ];
    my $hists;
    for ($f=$FF-1; $f>=0; $f--)  { $hists->[$f] = [ (0) x $L ]; }

    $f=$FF-1;
    foreach $s (@$sref) {
      if (++$f == $FF) {$f=0;}
      next if !defined($s);
      $$hists[$f][sprintf("%.0f",($s-$mins)/$eps)]++;
      $$numscs[$f]++;
      $numsc++;
    }
    return ($numsc, $numscs, $hists);
  }



sub difference  # (\@d0, \@d1)
  {
    my ($d0ref,$d1ref) = @_;
    my $dlen = scalar(@$d0ref);
    unless ($dlen==scalar(@$d1ref)) {
      carp "difference: Arrays of unequal length";
      return ();
    }

    my ($i, $delta);
    for($i=$dlen-1; $i>=0; $i--)
      { $delta->[$i] = $$d1ref[$i]-$$d0ref[$i]; }
    return $delta;
  }


##################################################################


sub mixcoefficient_E   # ($Avg,$E0,$E1)
  {
    my ($Avg,$E0,$E1) = @_;
    my $tauE = ($Avg-$E0)/($E1-$E0);
    if ($tauE<0) { $tauE=0; }
    if ($tauE>1) { $tauE=1; }
    return $tauE;
  }


sub mixcoefficient_ML  # (\@Hist, \@d0, \@d1)
  {
    my ($H,$d0,$d1) = @_;
    my $ddiff = difference($d0,$d1);
    return internal_mixcoefficient($H,$d0,$ddiff);
  }


sub mixcoefficient_FL  # (\@Hists, \@Histcounts, \@d0, \@d1)
  # Estimate tau by L MLs
  {
    my ($H, $Hc, $d0, $d1) = @_;
    my $L=scalar(@$H);
    my ($frame, $tau, $tauFL, $numsc);
    my $ddiff = difference($d0,$d1);

    $tauFL=0; $numsc=0;
    for ($frame=0; $frame<$L; $frame++)
      {
	$tau = internal_mixcoefficient($$H[$frame],$d0,$ddiff);
	$tauFL += $$Hc[$frame] * $tau;
        $numsc += $$Hc[$frame];
      }
    if ($numsc) { $tauFL /= $numsc; }
    return $tauFL;
  }


sub internal_mixcoefficient  # (\@sh,\@d0,\@ddiff, $guess)
  {
    my ($shref,$d0ref,$ddref,$tau) = @_;
    my $i;
    my $dlen=scalar(@$d0ref);
    unless($dlen==scalar(@$shref) && $dlen==scalar(@$ddref)) {
      carp("internal_mixcoefficient: Unequal distribution lengths");
      return undef;
    }

    # Find tau, such that L'(tau)=0
    my $taualt = 0.0001;           # hypothetical old value of right magnitude
    if (!defined($tau)) {$tau=0;}  # initial guess is tau=0 unless specified
    my ($L,$Ls,$Lss,  $fi,$r);

    while( abs($taualt-$tau) / (($tau>$taualt)?$tau:$taualt)  > 1E-8)
      {
	$L=0; $Ls=0; $Lss=0;
	for($i=0; $i<$dlen; $i++)
	  {
	    next if (!$$shref[$i]);
	    $fi = ($tau*$$ddref[$i]+$$d0ref[$i]);
            if ($fi==0) { carp("Emergency break: tau=$tau, i=$i"); return($tau); }
	    $r    = $$ddref[$i] / $fi;
	    $L   += $$shref[$i]*log($fi);
	    $Ls  += $$shref[$i]*$r;
	    $Lss += $$shref[$i]*($r*$r);
	  }
	$taualt=$tau;
	$tau += $Ls/$Lss;
	#printf "#      taualt=%g   tauneu=%g\n",$taualt,$tau;
	#printf "#      L=%g  L'=%g  L''=%g\n",$L,$Ls,-$Lss;
	if ($tau<=0) { $tau=0; }
	last if ($tau==0 && $taualt==0);
      }
    return $tau;
  }


sub mixcoefficient_plot  # (\@sh,\@d0,\@d1, $order)
  {
    my $shref=shift;
    my $d0ref=shift;
    my $d1ref=shift;
    my $order=shift;
    if (!defined($order)) { $order=-1; }
    my ($i,$tau);

    my $dlen=scalar(@$d0ref);
    die "mixture_coefficient: Unequal distribution lengths"
      unless(scalar(@$shref)==scalar(@$d0ref)
	     && scalar(@$shref)==scalar(@$d1ref));

    my @delta;
    for($i=$dlen-1; $i>=0; $i--)
      { $delta[$i] = $$d1ref[$i]-$$d0ref[$i]; }

    # Plot L(tau)
    my $ti;
    my $timax = 200;
    my @tis  = (0 .. $timax);
    my @taus = map { $_*1E-6 } @tis;
    my (@LL,@LLs,@LLss);  $LL[$timax]=0; $LLs[$timax]=0; $LLss[$timax]=0;
    for $ti (@tis)
      {
	$tau = $taus[$ti];
	my ($L,$Ls,$Lss);
	$L=0; $Ls=0; $Lss=0;
	for($i=0; $i<$dlen; $i++)
	  {
	    next if (!$$shref[$i]);
	    my $fi = ($tau*$delta[$i]+$$d0ref[$i]);
	    my $r  = $delta[$i] / $fi;
	    $L   += $$shref[$i]*log($fi);
	    $Ls  += $$shref[$i]*$r;
	    $Lss += $$shref[$i]*($r*$r);
	  }
	$LL[$ti]=$L;  $LLs[$ti]=$Ls;  $LLss[$ti]=-$Lss;
	printf "#         %-15g  %-15g %-15g %-15g\n",$tau,$L,$Ls,-$Lss;
      }
    if ($order==0)    { return @LL;   }
    elsif ($order==1) { return @LLs;  }
    elsif ($order==2) { return @LLss; }
    else { return (); }
  }

######################################################################
# similarity functions
######################################################################

sub byscore  # comparison function for paris (score,index)
  { return (($a->[0]) <=> ($b->[0])); }


sub cumsufscores  # (\@Matrix, order-statistic, @tau)
  # cumulative suffix scores
  {
    my $M = shift;
    my $order = shift;
    my $tref=shift;
    my @tau=@$tref;

    my $L = scalar(@$M);
    my ($i,$scorei,@sorted);
    my @result = (0) x ($L+1);

    for ($i=$L-1; $i>=0; $i--)
      {
	@sorted = sort { $a <=> $b } @{$M->[$tau[$i]]};
	$scorei = $sorted[$order];
	$result[$i] = $result[$i+1] + $scorei;
      }
    pop(@result);
    return(@result);
  }


sub profile_similarity  # (\@scoreA, \@scoreB, $tA, $tB, \@pi)
  # Compute similarity of two score matrices A and B
  # see README for details
  # Returns array of |A|+|B|-1 values, corresponding to joint match
  #   probabilities for all shifts (B before A, ..., B after A).
  {
    my $Aref=shift;
    my $Bref=shift;
    my $tA=shift;
    my $tB=shift;
    my $piref=shift;

    my $sh;
    my $Alen=scalar(@$Aref);
    my $Blen=scalar(@$Bref);
    my (@A, @B);
    my ($Al, $Bl, $L);
    my $asize = scalar(@$piref);
    my $nullen = [(0) x $asize];
    my ($dif);
    my ($i,$j,$sij,@score,@sorted,@tau);
    my (@Amax,@Amin,@Bmax,@Bmin);
    my (@prefix,@SAmem,@SBmem,@Probmem);
    my ($depth,$Probsum,$SA,$SB,$Prob);
    my @Probset;

    for ($sh=-($Blen-1); $sh<$Alen;  $sh++)
      {
	# (1) Create padded copies of A and B,
	#     where B begins 'sh' positions after A.
	@A = @$Aref; @B = @$Bref;
	if ($sh<0)
	  { unshift(@A,($nullen) x (-$sh)); }
	elsif ($sh>0)
	  { unshift(@B,($nullen) x $sh); }
	$Al=scalar(@A); $Bl=scalar(@B);
	$dif=$Al-$Bl;
	if ($dif<0)  # @A zu kurz
	  { push(@A,($nullen) x (-$dif)); }
	elsif ($dif>0)
	  { push(@B,($nullen) x $dif); }
	$L = scalar(@A); die if ($L!=scalar(@B));
	#print "shift=$sh:\n",matrix2string(\@A),"\n\n",matrix2string(\@B),"\n============\n\n";

	# (2) Find for all i: score(i) := max_j min(Aij,Bij)
	# Set tau to permutation of positions, sorted by score.
	# tau is the evaluation order of positions.
	@score = (undef) x $L;
	for ($i=0; $i<$L; $i++)
	  {
	    $score[$i]=[(-999999,$i)];
	    for ($j=0; $j<$asize; $j++)
	      {
		$sij = $A[$i][$j];
		if ($B[$i][$j]<$sij) { $sij=$B[$i][$j]; }
		if ($sij>$score[$i][0]) { $score[$i][0]=$sij; }
	      }
	  }
	@sorted = sort byscore @score;  #@score[0]=[-4.5,0]
	#@tau = map { $_->[1] } @sorted;
	@tau = (0..($L-1));
	#print "Score: ",join(" ",map { $_->[0] } @score),"\n";
	#print "Perm : ",join(" ",@tau),"\n";


	# (3) Precompute cumulative minscores and maxscores for
	#     suffixes of A and B
	# TODO: Use TAU!!!!!!
	@Amax = cumsufscores(\@A,$asize-1,\@tau);
	@Amin = cumsufscores(\@A,0,\@tau);
	@Bmax = cumsufscores(\@B,$asize-1,\@tau);
	@Bmin = cumsufscores(\@B,0,\@tau);
	#print "Amax: ",join(" ",@Amax),"\n";
	#print "Amin: ",join(" ",@Amin),"\n";
	#print "Bmax: ",join(" ",@Bmax),"\n";
	#print "Bmin: ",join(" ",@Bmin),"\n";

	# (4) Build tree.
	@prefix=(undef) x ($L+1); $depth=0;
	$Probsum=0; $SA=0; $SB=0; $Prob=1;
	
	while($depth>=0)
	  {
	    #print "depth=$depth,  ";
	    #if ($depth>0) {print join("",@prefix[0..$depth]);}
	    #print "\n";

	    if ($depth>=$L) { $depth--; next; }
	    if (!defined($prefix[$depth]))
	      { # Enter new depth:
		if ($SA+$Amax[$depth]<$tA) { $depth--; next; }
		if ($SB+$Bmax[$depth]<$tB) { $depth--; next; }
		if (($SA+$Amin[$depth]>=$tA) && ($SB+$Bmin[$depth]>=$tB))
		  {
		    $Probsum += $Prob;
		    #print "depth=$depth, ",join("",@prefix[0..($depth-1)]),"  Prob=$Prob   Probsum=$Probsum\n  SA=$SA,  SB=$SB\n";
		    $depth--; next;
		  }
		$prefix[$depth]=-1; next;
	      }
	    else
	      { # Increment $prefix[$depth] if possible.
		if ($prefix[$depth]>=$asize-1)
		  { $prefix[$depth]=undef; $depth--; next; }
		$prefix[$depth]++;

		# Compute correct prefix scores $SA, $SB, and $Prob.
		$SA = (($depth>0)?$SAmem[$depth-1]:0) 
		  + $A[$tau[$depth]][$prefix[$depth]];
		$SAmem[$depth]=$SA;
		$SB = (($depth>0)?$SBmem[$depth-1]:0) 
		  + $B[$tau[$depth]][$prefix[$depth]];
		$SBmem[$depth]=$SB;
		$Prob=(($depth>0)?$Probmem[$depth-1]:1) * $$piref[$prefix[$depth]];
		$Probmem[$depth]=$Prob;
		
		$depth++; $prefix[$depth]=undef;
	      }
	  }
	# Result is in $probsum!
	$Probset[$sh+($Blen-1)]=$Probsum;

      } # end for all shifts!

    # @Probset contains all results for all shifts!
    return(@Probset);
  }

######################################################################
# read functions
######################################################################

sub read_profile # (*FILEHANDLE, $head)
  # Read a SINGLE profile from filehandle FILEHANDLE;
  # and match given $head unless $head is undefined.
  # Return $head and array of profile rows.
  {
    local *FHANDLE = shift;
    my $head=shift;
    my (@prows, $lines);

    while(<FHANDLE>)
      {
        chomp;
        if (m/^>/)
          {
            m/(\d+)$/; $lines=$1;
	    if (defined($head) && $head ne $_) {
              carp("read_profile: Headers don't match: [$head] vs. [$_]");
              return ();
            }
	    $head=$_;
            @prows=();
            while(<FHANDLE>)
              {
                chomp;
                last if (m/^</);
                push(@prows,[split(" ",$_)]);
              }
            unless ($lines==scalar(@prows)) {
              carp("read_profile: wrong number of rows in [$head]");
              return ();
            }
            last;
          }
      }
    return ($head,@prows);
  }

##################################################################

sub read_distribution # (*FILEHANDLE, $head)
  # Read a SINGLE distribution from filehandle FILEHANDLE
  # (starts with two comment lines, ends with two blank lines),
  # and match given $head unless $head is undefined.
  # Return $head, $info, and array of probabilities
  {
    my $FN="read_distribution";
    local *FHANDLE = shift;
    my $heado=shift;
    my ($head, $info, $dist, $lines, $i);

    $head=undef;
    while(<FHANDLE>)
      {
        chomp;
        next unless m/^\#/;
        s/^\#\s*//;
        if (defined($heado))
          {
            if ($heado ne $_)
              { carp("$FN: headers don't match: [$heado] vs. [$_]"); }
          }
        $head=$_;
        $_=<FHANDLE>;
        if (! m/^\#\s*(.*?)\s*num=(\d+)\s*(.*)$/) {
          carp("$FN: info line not found [$head]"); return();
        }
        $info=$1."  ".$3;  $lines=$2;
        $$dist[$lines-1]=0; $i=0;
        while(<FHANDLE>)
          {
            chomp;
            next if m/^\#/;
            last if (!$_);
            $$dist[$i++]=[split(" ",$_)];
          }
        unless ($lines==$i) {
          carp("$FN: wrong number of rows in [$head]"); return();
        }
        last;
      }
    return ($head,$info,$dist);
  }

######################################################################

1;

######################################################################
# END of Module
######################################################################

