#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Prepares Error Distributions for plotting. 'File0' must contain the
# Score distribution of the null model (as output by ScoreDist.pl),
# while 'File1' must contain the distribution of the alternative model.
# If 'File1' is omitted, it is assumed that File0 contains null model
# and alternative model distributions in alternating order
#
# $PRG  [options]  File0  [File1]
#  -n windows      Compute n-window error probability alpha_n [n=1]
#  -m instances    Compute m-instance error probability beta_m [m=1]
#  -p              Write original pdfs (ignore -n and -m)
#  -t prior-tau    Compute FDR(tau) and FNDR(tau) (ignore -n and -m)
#
# The default (no options) is to compute alpha and beta
# (type-I and type-II error probabilities) for n=m=1.
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }


sub omspecial  # ($value, $n)
  {
    my ($y, $n) = @_;
    return ( ($y==0)? 0 : (1-exp($n*log($y))) );
  }

##################################################################

################
# MAIN
################

my ($n,$m,$pdf,$tau,$twofiles);

# PARSE OPTIONS
my %options;
getopts("Dhn:m:pt:", \%options)
  or die "$PRG: Illegal option given\n";
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
$n=$options{n} || 1;
$m=$options{m} || 1;
$pdf=$options{p};
$tau=$options{t};

my $file0 = $ARGV[0];
my $file1 = $ARGV[1];
if (!defined($file0)) { usage; die "File0 required"; }
if (!defined($file1)) { $twofiles=0; } else { $twofiles=1; }
open FNULL,"<$file0" or die "Cannot open '$file0";
if ($twofiles)
  { open FONE,"<$file1" or die "Cannot open '$file1"; }


# Processing
my ($head,$head0,$info0,$info1,$d0,$d1); $head="NONE";
my ($Erw0,$Erw1,$Erw);
my (@score,@alpha,@beta,@berror);
my $notes;
while ($head)
  {
    ($head,$info0,$d0) = read_distribution(*FNULL);
    last if (!defined($head));
    $head0=$head;
    if ($twofiles)
      { ($head,$info1,$d1) = read_distribution(*FONE,$head); }
    else
      { ($head,$info1,$d1) = read_distribution(*FNULL,$head); }
    die "Alternative distribution not found: Null=[$head0|$info0]"
      unless defined($head);
    $info0 =~ s/E=(\S+)//; $Erw0=$1;
    $info1 =~ s/E=(\S+)//; $Erw1=$1;
    die "Distribution info clash [$head]: Null=[$info0], Alt=[$info1]"
      unless ($info0 eq $info1);
    $Erw=$Erw1-$Erw0;

    # Set score according to info
    my ($minscore,$maxscore,$eps,$i);
    if ($info0 !~ m/min=(\S+)\s+eps=(\S+)\s+max=(\S+)/)
      { die "Unexpected info syntax [$info0]"; }
    else
      { ($minscore,$eps,$maxscore) = ($1,$2,$3); }
    $score[0]=$minscore; $score[scalar(@$d0)-1]=$maxscore;
    for ($i=1; $i<scalar(@$d0)-1; $i++)
      { $score[$i]=roundeps($eps*$i+$minscore,$eps); }

    # Set alpha, beta according to options
    if(defined($pdf))
      {
        @alpha = map { $_->[0] } @$d0;
        @beta  = map { $_->[0] } @$d1;
        $notes="";
      }
    elsif(defined($tau))
      {
        my (@aa,@bb);
        @aa = map { (1-$tau)*($_->[2]) } @$d0;
        @bb = map { $tau*($_->[2]) } @$d1;
        for($i=0; $i<scalar(@aa); $i++)
          { $alpha[$i] = ($aa[$i]==0)? 0: $aa[$i]/($aa[$i]+$bb[$i]); }

        @bb = map { $tau*($_->[1]) } @$d1;
        @aa = map { (1-$tau)*($_->[1]) } @$d0;
        for($i=0; $i<scalar(@aa); $i++)
          { $beta[$i] = ($bb[$i]==0)? 0: $bb[$i]/($bb[$i]+$aa[$i]); }
        $notes = "tau=$tau";

        @aa = map { (1-$tau)*($_->[2]) } @$d0;
        @bb = map { $tau*($_->[1]) } @$d1;
        for($i=0; $i<scalar(@aa); $i++)
          { $berror[$i] = $aa[$i]+$bb[$i]; }
      }
    else
      {
        if ($n==1)
          { @alpha= map { $_->[2] } @$d0; }
        else
          { @alpha= map { omspecial($_->[1],$n) } @$d0; }
        if ($m==1)
          { @beta= map { $_->[1] } @$d1; }
        else
          { @beta= map { omspecial($_->[2],$m) } @$d1; }
        $alpha[0]=1; $beta[0]=0;
        $notes = "n=$n  m=$m";
      }

    # Print
    print "# $head\n# $info1  E=$Erw  num=",scalar(@alpha),"  $notes\n";
    for($i=0; $i<scalar(@alpha); $i++)
      {
        print "$score[$i]  $alpha[$i]  $beta[$i]";
        if (defined($tau)) { print "  $berror[$i]"; }
        print "\n";
      }
    print "\n\n";
  }

# Close up
close(FNULL);
if ($twofiles) { close(FONE); }

#################################################################

