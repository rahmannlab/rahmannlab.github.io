#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Reads score matrix file and computes score distribution,
# as specified by either -d or -p option.
#
# $PRG  [options]  ScoreMatrixFile
#  -d Distribution     Assumed distribution
#       default          distribution given in score matrix file
#                          or in profile file (when -p given) [DEFAULT]
#       uni[form]        uniform distribution (ignores -p)
#       sum|av[erage]    average distribution of the profile (with -p)
#       GC=[##|av]       iid distribution with ##% GC-content (e.g. 50)
#                          or average GC content of profile (with -p)
#  -p ProfileFile      Assumed distribution according to profile
#  -e granularity      Rounding granularity (DEFAULT: from Scorematrix)
#
# For p-values, give no arguments
# For distribution under profile, use '-p ProfileFile'
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

##################################################################

sub info2eps  # ($info)
  {
    my ($info) = @_;
    if ($info =~ m/^<\s+(\S+)\s+/)
      { return $1; }
    die "$PRG: info2eps: No granularity (eps) found in [$info]";
  }

sub info2dist  # ($info)
  {
    my ($info) = @_;
    if ($info =~ m/\[\s+(.*)\s+\]/)
      { return(split(" ",$1)); }
    die "$PRG: info2dist: No distribution found in [$info]";
  }

##################################################################

################
# MAIN
################

my ($dist,$profname,$eps);


# PARSE OPTIONS
my %options;
getopts("Dhd:p:e:", \%options)
  or die "$PRG: Illegal options given\n";
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
$dist=$options{d} || 'default';
$profname=$options{p} || '-';
$eps=$options{e} || '0';


my ($needp);
my ($head, $lines, $info, $seps);
my (@prows, @srows);

$needp = defined($options{p});
if (($dist =~ m/^uni/i) || ($dist =~ m/^GC=([\d\.]+)$/i))
  { $needp=0; }
if (!$needp && (($dist =~ m/av|sum/)))
  { die "$PRG: Option '-d $dist' needs option -p (use '-p -' for STDIN)"; }
if ($needp)
  { open(PRO,"<$profname") or die "$PRG: Cannot open '$profname'"; }


# Processing
while(<>)
  {
    chomp;
    if (m/^>/)
      {
        m/(\d+)$/; $lines=$1;
        $head=$_; @srows=();
        while(<>)
          {
            chomp;
            if (m/^</) {$info=$_; last;}
            push(@srows,[ split(" ",$_) ]);
          }
        die "$PRG: Wrong number of rows in [$head]"
          unless ($lines==scalar(@srows));
        $seps=info2eps($info);

        # Round to granularity
        if ($eps>0)
          {
            if ($eps<$seps)
              { warn "$PRG: Given granularity $eps is smaller than in score file $seps"; }
            if ($eps/$seps != sprintf("%.0f",$eps/$seps))
              { warn "$PRG: Given granularity $eps is not a multiple of granularity $seps in score file"; }
            @srows = roundeps(\@srows,$eps);
            $seps=$eps;
          }

        # Build @prows: Read profile if required
        # -p file -d default  -> Take profile as is
        # -p file -d av       -> Take average profile
        # -p file -d GC=av    -> Take GV average profile
        my @backgr;
        if ($needp)
          {
            ($head,@prows) = read_profile(*PRO,$head);
            if ($dist !~ m/^d/i)
              {
                @backgr=getdist($dist,\@prows);
                for(my $i=0; $i<$lines; $i++) { $prows[$i]=[@backgr]; }
              }
          }
        else
          # no $needp: -d uni,  -d GC=##
          {
            if ($dist =~ m/^d/i)
              { @backgr=info2dist($info); }
            else
              { @backgr=getdist($dist,\@srows); }
            $#prows=$lines-1;
            for(my $i=0; $i<$lines; $i++) { $prows[$i]=[@backgr]; }
          }
        die "$PRG: Scores and profile have diffent numbers of lines [$head]"
          unless (scalar(@prows)==$lines);

        my ($minscore,$maxscore, $Erw, $sdist, $cdist);
        ($minscore,$maxscore,$sdist) = scoredist(\@srows,\@prows,$seps);
        $Erw = scoreexpectation(\@srows,\@prows,$seps);

        my $numscores = 1+sprintf("%.0f",(($maxscore-$minscore)/$seps));
        $numscores++; $maxscore+=$seps;
        $cdist=cumsums($sdist);

	$head =~ s/\s+(\d+)$//;
	$head =~ s/^>//;
        print "# $head\n";
        print "# min=$minscore   eps=$seps   max=$maxscore  ";
        print "E=$Erw  num=$numscores\n";
        print matrix2string($cdist);
        print "\n0  1  0\n\n\n";
      }
  }

if ($needp) { close PRO; }

#################################################################

