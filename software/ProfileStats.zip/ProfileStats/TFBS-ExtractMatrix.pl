#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Extracts TFBS matrices from TRANSFAC file 'matrix.dat' into
# a simpler file format
#
# Usage:
# $PRG  [options]  TRANSFAC-matrix-file(s)
#   -i 'ID1[,ID2,...]'  Extract matrices with specified IDs.
#   -p 'pattern'        Extract matrices whose ID matches pattern
#         Single quotes protect IDs/pattern from shell interpretation.
#         If both -i and -p are given, this is taken as a logical OR.
#   -h                  Help on usage (applies to all scripts)
#   -D                  Debug Mode (applies to all scripts)
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; exit; }

my $debug=0;
sub debug
  { if($debug) {print STDERR @_,"\n"; } }

#################################################################

my @IDs = ();
my $pat = undef;

#################################################################

sub printout # Print matrix if it matches
  {
    my ($ID,$NA,$DE,$rr)=@_;
    my $good=(defined($pat)||scalar(@IDs))?0:1;
    if (defined($pat) && $ID =~ /$pat/) { $good = 1; }
    if (scalar(@IDs))
      {
        my $id;
        foreach $id (@IDs)
          { if ($ID eq $id)  { $good=1; } }
      }
    return unless $good;

    my $nrows=scalar(@$rr);
    print ">$ID|$NA|$DE  $nrows\n";
    print join("\n",@$rr);
    print "\n<\n";
  }

#################################################################


# PARSE OPTIONS
my %options;
getopts("Dhi:p:", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
$debug=$options{D};
if ($options{h}) { usage; exit(1); }

if (defined($options{i}))
  {  my $i;
     @IDs = split(",",$options{i});
     debug("[",join(" ",@IDs),"]\n");
     for ($i=scalar(@IDs)-1; $i>=0; $i--)
       { $IDs[$i] =~ s/^\s+//; $IDs[$i] =~ s/\s+$//; }
   }
if (defined $options{p})
  {
    if ($options{p} =~ /\@/) {die "No '\@' allowed in pattern";}
    $pat=$options{p};
    die "Invalid pattern: '$pat'" unless ProfileStats::is_valid_pattern($pat);
    $pat=qr($pat);
    debug($pat);
  }


# Processing loop: Get AC; ID; NA; DE; P0..XX
my $type;
my ($AC,$ID,$NA,$DE,@rows,@val,@rsum);
my %IDseen=(); $AC=""; $NA=$DE="None";
@rows=(); @rsum=();
my $nrows=0;
my ($s,$ss,$v);

while(<>)
  {
    chomp;
    $type=substr($_,0,2);
    if ($type eq "AC")
      {
        if($AC) { printout($ID,$NA,$DE,\@rows); }
        $AC=$ID=""; $NA=$DE="None"; @rows=(); @rsum=();
        s/^AC\s+//;
        $AC=$_;
      }
    elsif ($type eq "ID")
      {
        s/^ID\s+//;
        $ID=$_;
        if(exists($IDseen{$ID}))
          { die "ID [$ID] already exists for AC $IDseen{$ID}"; }
        $IDseen{$ID}=$AC;
      }
    elsif ($type eq "NA")
      {
        s/^NA\s+//;
        $NA=$_;
      }
    elsif ($type eq "DE")
      {
        s/^DE\s+//;
        $DE=$_;
      }
    elsif ($type eq "P0")
      {
        if (! m/^P0\s+A\s+C\s+G\s+T/) { die "Wrong P0 line [$_]"; }
        while (<>)
          {
            chomp; $type=substr($_,0,2);
            last if ($type eq "XX");
            s/^\d+\s+//; s/\s+\D\s*$//;
            @val=split; $s=0;
            foreach $v (@val) { $s+=$v; }
            push(@rows,join(" ",@val));
            push(@rsum,$s);
          }
      }
  }
if($AC) { printout($ID,$NA,$DE,\@rows); }
