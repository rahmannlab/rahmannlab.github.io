#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Reads simple-format profile matrix file and converts profiles
# into Score matrices with given background distribution
# and information units.
#
# Usage:
# $PRG  [options]  SimpleMatrixFile(s)
#  -d Distribution     Background distribution, i.e., one of
#       uni[form]        uniform distribution
#       sum|av[erage]    average distribution of the profile
#       GC=[nn|av]       iid distribution with nn% GC-content (e.g. 50)
#                          or average GC content of profile [DEFAULT]
#  -u Units            Score (information) units
#       bit[s]|nat[s]|dit[s]  (DEFAULT=nat)
#  -s scaling-factor   Score scaling factor (DEFAULT=1.0)
#  -e granularity      Rounding granularity (DEFAULT=0.01)
#
# Recommended and Default is  '-u nats -s 1.0 -e 0.01'
#   This is of course equivalent to '-u nats -s 100 -e 1'
#   The former leaves scores unchanges and rounds to granularity 1/100;
#   the latter multiplies scores by 100 and rounds to integers.
# Default is '-d GC=av', as this requires no additional information.
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

##################################################################


################
# MAIN
################

my ($dist,$scale,$eps,$unit);


# PARSE OPTIONS
my %options;
getopts("Dhd:u:s:e:", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
if( $options{h}) { usage; exit(1); }
$ProfileStats::DEBUG=$options{D};
$dist=$options{d} || 'GC=av';
$scale=$options{s} || '1.0';
$eps=$options{e} || '0.01';
$unit=$options{u} || 'nats';
if ($unit =~ m/^n/i) {}
elsif ($unit =~ m/^b/i) {$scale/=log(2);}
elsif ($unit =~ m/^d/i) {$scale/=log(10);}
else { usage; die "Unrecognized information unit [$unit] given"; }


my ($head, $lines);
my (@prows, @backgr, @srows);

# Processing
while(<>)
  {
    chomp;
    if (m/^>/)
      {
        m/(\d+)$/; $lines=$1;
        $head=$_; @prows=(); @srows=();
        while(<>)
          {
            chomp;
            last if (m/^</);
            push(@prows,[ split(" ",$_) ]);
          }
        die "Wrong number of rows in [$head]"
          unless ($lines==scalar(@prows));
        # Convert profile matrix to score:
        @backgr=getdist($dist,\@prows)
          or die "Error processing getdist for [$head]";
        @srows=profile2score(\@prows,\@backgr,$scale,$eps)
          or die "Error processing profile2score for [$head]";

        # Write score matrix:
        print $head,"\n";
        print matrix2string(\@srows),"\n";
        print "< ",$eps," [ ",join(" ",@backgr)," ]\n\n";
      }
  }

#################################################################

