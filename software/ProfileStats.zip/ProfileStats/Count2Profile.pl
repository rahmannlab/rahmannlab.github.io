#!/bin/perl -w
use strict;
use strict 'refs';
use Getopt::Std;
use ProfileStats;

my $PRG=$0; $PRG=~s|^.*/||;
my $USAGE=<<ENDOFUSAGE;
##################################################################
#
# $PRG $ProfileStats::Version;  (c) $ProfileStats::Author, $ProfileStats::Date
# Reads simple format matrix file and normalizes by row-sum.
# In other words, converts count matrix into Profile P.
#
# Usage:
# $PRG  [options]  SimpleMatrixFile(s)
#   -h   Help
##################################################################
ENDOFUSAGE
$USAGE =~ s/\#( )?//g;
$USAGE =~ s/\n//;

sub usage
  { print STDERR $USAGE; }

#################################################################

################
# MAIN
################

# PARSE OPTIONS
my %options;
getopts("Dh", \%options);
while (($ARGV[0]) && ($ARGV[0] =~ /^-/)) { shift; }
$ProfileStats::DEBUG=$options{D};
if ($options{h}) {usage; exit(1);}


my ($head, $lines);
my (@rows,@prows);

# Processing
while(<>)
  {
    chomp;
    if (m/^>/)
      {
        m/(\d+)$/; $lines=$1;
        $head=$_; @rows=(); @prows=();
        while(<>)
          {
            chomp;
            last if (m/^</);
            push(@rows,[split(" ",$_)]);
          }
        die "$PRG: Wrong number of rows in [$head]"
          unless ($lines==scalar(@rows));
        # Regularize matrix:
        @prows=normalizerows(\@rows)
          or die "$PRG: Malformatted matrix [$head] ";
        # Write regularized matrix:
        print $head,"\n";
        print matrix2string(\@prows),"\n<\n";
      }
  }

#################################################################
