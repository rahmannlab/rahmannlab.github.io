#!/bin/sh
perl -d:DProf TFBS-Count.pl  -u  ../experiments/fdr/V-hq.profile  ../experiments/seq/TEST.seq
