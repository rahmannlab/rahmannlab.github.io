#!/bin/sh
TFBS-Count.pl  -r  ../experiments/V-hq.profile  ../experiments/seq/humanpromoters.seq  > humanpromoters.results
